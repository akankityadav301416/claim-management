package com.oneClickTech.utils;

import java.math.BigDecimal;
import java.util.Map;

import com.oneClickTech.entity.ExpenseItem;

public class ValidationUtil {
    public static boolean isWithinPolicyLimits(ExpenseItem item, Map<String, BigDecimal> limits) {
        return item.getAmount().compareTo(limits.getOrDefault(item.getCategory().getName(), BigDecimal.ZERO)) <= 0;
    }
    
}
