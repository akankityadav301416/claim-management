package com.oneClickTech.controller;

public class FileUploadController {

//     POST
// /claims/{id}/attachments
// Upload document or receipt
// GET
// /claims/{id}/attachments
// List uploaded files
// GET
// /claims/{id}/attachments/{fileId}
// Download file
// DELETE
// /claims/{id}/attachments/{fileId}
// Delete uploaded file

    
}
