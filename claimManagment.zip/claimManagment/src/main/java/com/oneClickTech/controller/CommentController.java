package com.oneClickTech.controller;

import java.lang.reflect.Method;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.oneClickTech.entity.Comment;
import com.oneClickTech.service.CommentService;
import com.oneClickTech.utils.AuthUtil;

@RequestMapping("/api/v1/claims")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @PostMapping("/{claimId}/comments")
    public ResponseEntity<Comment> add(@PathVariable("claimId") Long claimId, @RequestParam String message) {
        return ResponseEntity.ok(commentService.addComment(claimId, message, AuthUtil.getCurrentUser()));
    }

    @GetMapping("/{claimId}/comments")
    public ResponseEntity<List<Comment>> list(@PathVariable Long claimId) {
        return ResponseEntity.ok(commentService.getComments(claimId));
    }

    @PostMapping("/{claimId}/comments/{commentId}/reply")
    public ResponseEntity<Comment> addCommentReply(@PathVariable("claimId") long claimId, @PathVariable("commentId") long commentId, @RequestParam String msg) {
        return ResponseEntity.ok(commentService.addCommentReply(claimId, msg, AuthUtil.getCurrentUser(), commentId));
    }

}
