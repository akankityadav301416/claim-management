package com.oneClickTech.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oneClickTech.entity.User;
import com.oneClickTech.repository.UserRepository;
import com.oneClickTech.utils.AuthUtil;

@RestController("/api/v1/auth/")
public class AuthController {

    @Autowired
    private UserRepository userRepo;

    @GetMapping("/me")
    public ResponseEntity<User> getCurrentUserDetails() {
        String username = AuthUtil.getCurrentUser();
        return ResponseEntity.of(userRepo.findByUsername(username));
    }

}
