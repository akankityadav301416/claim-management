package com.oneClickTech.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.oneClickTech.entity.Claim;
import com.oneClickTech.entity.ExpenseCategory;
import com.oneClickTech.entity.ExpenseItem;
import com.oneClickTech.repository.ExpenseCategoryRepositoy;
import com.oneClickTech.repository.ExpenseItemRepository;
import com.oneClickTech.service.ClaimService;

@RestController("/api/v1/claims")
public class ClaimController {

    @Autowired
    private ClaimService claimService;
    @Autowired
    private ExpenseItemRepository itemRepository;
    @Autowired
    private ExpenseCategoryRepositoy categoryRepositoy;

    @PostMapping
    public ResponseEntity<Claim> create(@RequestBody Claim claim) {
        return ResponseEntity.ok(claimService.createClaim(claim));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Claim> get(@PathVariable Long id) {
        return ResponseEntity.ok(claimService.getClaim(id));
    }

    @GetMapping
    public ResponseEntity<List<Claim>> list(@RequestParam Long userId) {
        return ResponseEntity.ok(claimService.listClaimsByUser(userId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Claim> update(@PathVariable Long id, @RequestBody Claim claim) {
        return ResponseEntity.ok(claimService.updateClaim(id, claim));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        claimService.deleteClaim(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{claimId}/items")
    public ResponseEntity<ExpenseItem> addExpense(@PathVariable("claimId") long claimId,
            @RequestBody ExpenseItem expenseItem) {
        Claim claim = claimService.getClaim(claimId);

        if (expenseItem.getCategory() != null && expenseItem.getCategory().getId() != null) {
            ExpenseCategory eCategory = categoryRepositoy.findById(expenseItem.getCategory().getId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "INVALID_CATEGORY"));
            expenseItem.setCategory(eCategory);
        }
        expenseItem.setClaim(claim);
        ExpenseItem item = itemRepository.save(expenseItem);
        return ResponseEntity.status(HttpStatus.CREATED).body(item);
    }

    @PutMapping("/{claimId}/items/{itemId}")
    public ResponseEntity<ExpenseItem> updateItem(@PathVariable("claimId") long claimId,
            @PathVariable("itemId") long itemId, @RequestBody ExpenseItem expenseItem) {
        ExpenseItem item = itemRepository.findById(itemId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "INVALID_ITEM"));
        if (item.getClaim().getId() != claimId) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "INVALID_REQUEST");
        }
        item.setAmount(expenseItem.getAmount());
        item.setCategory(expenseItem.getCategory());
        item.setDate(expenseItem.getDate());
        item.setDescription(expenseItem.getDescription());
        ExpenseItem saved = itemRepository.save(item);
        return ResponseEntity.ok(saved);
    }

    @DeleteMapping("/{claimId}/items/{itemId}")
    public ResponseEntity<Void> deleteItem(
            @PathVariable Long claimId,
            @PathVariable Long itemId) {

        ExpenseItem item = itemRepository.findById(itemId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Item not found"));

        if (!item.getClaim().getId().equals(claimId)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Item does not belong to claim");
        }

        itemRepository.delete(item);
        return ResponseEntity.noContent().build();
    }

}
