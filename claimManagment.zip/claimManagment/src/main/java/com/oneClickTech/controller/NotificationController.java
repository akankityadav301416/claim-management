package com.oneClickTech.controller;

public class NotificationController {

//     POST
// /notifications/email
// Trigger email alert (system/internal use)
// GET
// /notifications
// Get current user’s notification feed

    
}
