package com.oneClickTech.controller;

public class StatusAndTrackingController {

//     GET
// /claims/{id}/status
// Get current claim status
// GET
// /claims/{id}/timeline
// Get full timeline view
// GET
// /claims/stats
// Get counts by status (e.g., Pending, Approved, Rejected

    
}
