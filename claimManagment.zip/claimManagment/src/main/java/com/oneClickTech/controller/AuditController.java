package com.oneClickTech.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.oneClickTech.entity.AuditLogs;
import com.oneClickTech.repository.AuditLogRepository;

@RestController("/api/v1/audits/")
public class AuditController {

    @Autowired
    private AuditLogRepository auditRepo;

    @GetMapping("/{claimId}")
    public ResponseEntity<List<AuditLogs>> list(@PathVariable Long claimId) {
        return ResponseEntity.ok(auditRepo.findByClaimId(claimId));
    }

    @GetMapping
    public ResponseEntity<List<AuditLogs>> getAuditLogs(){
        return ResponseEntity.ok(auditRepo.findAll());
    }
}
