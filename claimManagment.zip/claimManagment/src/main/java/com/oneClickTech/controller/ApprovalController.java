package com.oneClickTech.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oneClickTech.entity.ApprovalStage;
import com.oneClickTech.entity.Claim;
import com.oneClickTech.repository.ApprovalStageRepository;
import com.oneClickTech.service.ApprovalService;
import com.oneClickTech.service.ClaimService;
import com.oneClickTech.utils.AuthUtil;

@RestController("/api/v1/approvals")
public class ApprovalController {

    @Autowired
    private ApprovalService approvalService;

    @Autowired
    private ClaimService claimService;

    @Autowired
    private ApprovalStageRepository approvalStageRepository;

    @GetMapping("/pending")
    public ResponseEntity<List<Claim>> getPendingApprovals() {
        String currentUser = AuthUtil.getCurrentUser();
        List<Claim> claims = claimService.getClaimsPendingApprovalForUser(currentUser);
        return ResponseEntity.ok(claims);
    }

    @PutMapping("/claims/{id}/manager")
    public ResponseEntity<Void> managerApproval(
            @PathVariable Long id,
            @RequestParam boolean approved,
            @RequestParam String comment) {
        String user = AuthUtil.getCurrentUser();
        if (approved) {
            approvalService.approveClaim(id, "MANAGER", user, comment);
        } else {
            approvalService.revertClaim(id, "MANAGER", comment);
        }
        return ResponseEntity.ok().build();
    }

    @PutMapping("/claims/{id}/accounts")
    public ResponseEntity<Void> accountsReview(
            @PathVariable Long id,
            @RequestParam boolean approved,
            @RequestParam String comment) {
        String user = AuthUtil.getCurrentUser();
        if (approved) {
            approvalService.approveClaim(id, "ACCOUNTS", user, comment);
        } else {
            approvalService.revertClaim(id, "ACCOUNTS", comment);
        }
        return ResponseEntity.ok().build();
    }

    @PutMapping("/claims/{id}/accounts-head")
    public ResponseEntity<Void> accountsHeadApproval(
            @PathVariable Long id,
            @RequestParam boolean approved,
            @RequestParam String comment) {
        String user = AuthUtil.getCurrentUser();
        if (approved) {
            approvalService.approveClaim(id, "ACCOUNTS_HEAD", user, comment);
        } else {
            approvalService.revertClaim(id, "ACCOUNTS_HEAD", comment);
        }
        return ResponseEntity.ok().build();
    }

    @PutMapping("/claims/{id}/revert")
    public ResponseEntity<Void> revertClaim(
            @PathVariable Long id,
            @RequestParam String role,
            @RequestParam String comment) {
        approvalService.revertClaim(id, role, comment);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/history/{claimId}")
    public ResponseEntity<List<ApprovalStage>> getApprovalHistory(@PathVariable Long claimId) {
        List<ApprovalStage> history = approvalStageRepository.findByClaimId(claimId);
        return ResponseEntity.ok(history);
    }

}
