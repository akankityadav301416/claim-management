package com.oneClickTech.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity
@Data
public class ExpenseItem {

    @Id
    @GeneratedValue
    private Long id;
    private LocalDate date;
    private BigDecimal amount;
    private String description;

    @ManyToOne
    private ExpenseCategory category;
    @ManyToOne
    private Claim claim;

}
