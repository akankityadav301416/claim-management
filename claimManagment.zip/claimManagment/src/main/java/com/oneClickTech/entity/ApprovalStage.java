package com.oneClickTech.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class ApprovalStage {

    @Id
    @GeneratedValue 
    private Long id;
    private Long claimId;
    private String stage; // MANAGER, ACCOUNTS, ACCOUNTS_HEAD
    private String status;
    private LocalDateTime updatedAt;
    private String updatedBy;
    private String comment;
    
}
