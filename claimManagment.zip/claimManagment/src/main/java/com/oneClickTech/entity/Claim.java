package com.oneClickTech.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Data;

@Entity
@Data
public class Claim {
    @Id 
    @GeneratedValue 
    private Long id;
    private Long userId;
    private String status;
    private BigDecimal totalAmount;
    private LocalDate submittedAt;

    @OneToMany(mappedBy = "claim", cascade = CascadeType.ALL)
    private List<ExpenseItem> items;
    
}
