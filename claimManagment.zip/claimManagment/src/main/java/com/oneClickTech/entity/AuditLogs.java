package com.oneClickTech.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class AuditLogs {

    @Id
    @GeneratedValue 
    private Long id;
    private Long claimId;
    private String action;
    private String actor;
    private LocalDateTime timestamp;
    private String details;
    
}
