package com.oneClickTech.service;

import java.util.List;

import com.oneClickTech.entity.Comment;

public interface CommentService {
    Comment addCommentReply(Long claimId, String message, String user, Long parentId);
    Comment addComment(long claimId, String mesaage, String user);
    List<Comment> getComments(Long claimId);
}
