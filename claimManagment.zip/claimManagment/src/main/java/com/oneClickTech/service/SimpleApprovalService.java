package com.oneClickTech.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oneClickTech.entity.ApprovalStage;
import com.oneClickTech.repository.ApprovalStageRepository;

@Service
public class SimpleApprovalService implements ApprovalService {

    @Autowired
    private ApprovalStageRepository approvalStageRepository;

    @Override
    public void approveClaim(Long claimId, String role, String user, String comment) {
        ApprovalStage approval = new ApprovalStage();
        approval.setClaimId(claimId);
        approval.setComment(comment);
        approval.setStage(role);
        approval.setUpdatedBy(user);
        approval.setUpdatedAt(LocalDateTime.now());
        approvalStageRepository.save(approval);
    }

    @Override
    public void revertClaim(Long claimId, String role, String comment) {
        ApprovalStage approval = new ApprovalStage();
        approval.setClaimId(claimId);
        approval.setComment(comment);
        approval.setStage(role);
        approval.setUpdatedAt(LocalDateTime.now());
        approvalStageRepository.save(approval);
    }
    
}
