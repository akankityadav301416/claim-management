package com.oneClickTech.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.oneClickTech.entity.Comment;
import com.oneClickTech.repository.CommentRepository;

public class SimpleCommentServcie implements CommentService{

    @Autowired
    private CommentRepository commentRepository;

    private Long claimId;
    private Long parentId;
    private String user;
    private String message;
    private LocalDateTime createdAt;

    @Override
    public Comment addCommentReply(Long claimId, String message, String user, Long parentId) {
        Comment comment = new Comment();
        comment.setClaimId(claimId);
        comment.setMessage(message);
        comment.setUser(user);
        comment.setParentId(parentId);
        comment.setCreatedAt(LocalDateTime.now());
        return commentRepository.save(comment);
    }

    @Override
    public Comment addComment(long claimId, String mesaage, String user) {
        Comment comment = new Comment();
        comment.setClaimId(claimId);
        comment.setMessage(message);
        comment.setUser(user);
        comment.setCreatedAt(LocalDateTime.now());
        return commentRepository.save(comment);
    }

    @Override
    public List<Comment> getComments(Long claimId) {
       return commentRepository.findByClaimId(claimId);
    }
    
}
