package com.oneClickTech.service;

public interface ApprovalService {
    void approveClaim(Long claimId, String role, String user, String comment);
    void revertClaim(Long claimId, String role, String comment);
}
