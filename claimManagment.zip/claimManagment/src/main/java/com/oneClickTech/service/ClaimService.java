package com.oneClickTech.service;

import java.util.List;

import com.oneClickTech.entity.Claim;

public interface ClaimService {
    Claim createClaim(Claim claim);
    Claim updateClaim(Long id, Claim claim);
    Claim getClaim(Long id);
    List<Claim> listClaimsByUser(Long userId);
    void deleteClaim(Long id);
    List<Claim> getClaimsPendingApprovalForUser(String currentUser);
}
