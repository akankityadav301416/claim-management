package com.oneClickTech.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.oneClickTech.entity.ApprovalStage;
import com.oneClickTech.entity.Claim;
import com.oneClickTech.entity.ExpenseItem;
import com.oneClickTech.repository.ApprovalStageRepository;
import com.oneClickTech.repository.ClaimRepository;

import jakarta.persistence.CascadeType;
import jakarta.persistence.OneToMany;

public class SimpleClaimService implements ClaimService {

    @Autowired
    private ClaimRepository claimRepository;

    @Autowired
    private ApprovalStageRepository approvalStageRepository;

    @Override
    public Claim createClaim(Claim claim) {
        return claimRepository.save(claim);
    }

    private Long userId;
    private String status;
    private BigDecimal totalAmount;
    private LocalDate submittedAt;

    @OneToMany(mappedBy = "claim", cascade = CascadeType.ALL)
    private List<ExpenseItem> items;

    @Override
    public Claim updateClaim(Long id, Claim claim) {
        Claim temp = claimRepository.findById(id).orElseThrow(()-> new RuntimeException("claim not found " + id));
        temp.setUserId(claim.getUserId());
        temp.setStatus(claim.getStatus());
        temp.setTotalAmount(claim.getTotalAmount());
        temp.setSubmittedAt(claim.getSubmittedAt());
        return claimRepository.save(temp);
    }

    @Override
    public Claim getClaim(Long id) {
        return claimRepository.findById(id).orElseThrow(() -> new RuntimeException("Claim not found for id " + id));
    }

    @Override
    public List<Claim> listClaimsByUser(Long userId) {
        return claimRepository.findByUserId(userId);
    }

    @Override
    public void deleteClaim(Long id) {
        claimRepository.deleteById(id);
    }

    @Override
    public List<Claim> getClaimsPendingApprovalForUser(String currentUser) {
        List<ApprovalStage> pendingStages = approvalStageRepository.findByStageAndUpdatedBy("PENDING", currentUser);

        Set<Long> claimIds = pendingStages.stream()
            .map(ApprovalStage::getClaimId)
            .collect(Collectors.toSet());

        return claimRepository.findAllById(claimIds);
    }
    
}
