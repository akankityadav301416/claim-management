package com.oneClickTech.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.oneClickTech.entity.ApprovalStage;

public interface ApprovalStageRepository extends JpaRepository<ApprovalStage, Long>{
    
    List<ApprovalStage> findByClaimId(Long claimId);
    List<ApprovalStage> findByStageAndUpdatedBy(String stage, String user);
}
