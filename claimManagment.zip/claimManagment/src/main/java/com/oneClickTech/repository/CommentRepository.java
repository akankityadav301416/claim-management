package com.oneClickTech.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.oneClickTech.entity.Comment;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    
    List<Comment> findByClaimId(Long claimId);
}
