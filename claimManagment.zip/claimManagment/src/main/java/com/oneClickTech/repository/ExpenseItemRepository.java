package com.oneClickTech.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.oneClickTech.entity.ExpenseItem;

public interface ExpenseItemRepository extends JpaRepository<ExpenseItem, Long> {
    
}
