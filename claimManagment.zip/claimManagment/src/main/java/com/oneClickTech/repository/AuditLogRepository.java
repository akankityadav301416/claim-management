package com.oneClickTech.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.oneClickTech.entity.AuditLogs;

public interface AuditLogRepository extends JpaRepository<AuditLogs, Long> {
    
    List<AuditLogs> findByClaimId(Long claimId);
}
